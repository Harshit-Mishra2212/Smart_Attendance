# face_recognition/__init__.py
from .api import face_api
