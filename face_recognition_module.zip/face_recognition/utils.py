# face_recognition/utils.py
import os, pickle
from typing import Dict, List

BASE_DIR = os.path.dirname(__file__)
ENCODINGS_PATH = os.path.join(BASE_DIR, "encodings", "encodings.pickle")
KNOWN_DIR = os.path.join(BASE_DIR, "known_faces")

os.makedirs(os.path.dirname(ENCODINGS_PATH), exist_ok=True)
os.makedirs(KNOWN_DIR, exist_ok=True)

def save_encodings(data: Dict[str, List[float]]):
    with open(ENCODINGS_PATH, "wb") as f:
        pickle.dump(data, f)

def load_encodings():
    if not os.path.exists(ENCODINGS_PATH):
        return {}
    with open(ENCODINGS_PATH, "rb") as f:
        return pickle.load(f)
