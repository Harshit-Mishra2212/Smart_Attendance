# Face Recognition Module

Install requirements:

python -m venv venv
venv\Scripts\activate
pip install -r requirements_face.txt

Prepare known faces:
- Create directories under `known_faces/` named after each student ID (or roll no)
- Put 1-5 clear face images (frontal) in each folder.

Rebuild encodings:
python -c "from face_recognition.face_recog import encode_known_faces; encode_known_faces(force_rebuild=True)"

Run local camera test:
python -m face_recognition.camera_stream

Integrate with Flask app:

from face_recognition import face_api
app.register_blueprint(face_api)
